#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# NVFP4 quantization using ModelOpt export_hf_checkpoint
# Input: $MODEL_PATH (set by platform, default /models/MiniCPM-SALA)
# Output: /workspace/nvfp4_model (served with --quantization modelopt_fp4)

MODEL_INPUT="${MODEL_PATH:-/models/MiniCPM-SALA}"
MODEL_OUTPUT="/workspace/nvfp4_model"
CALIB_DATA="/opt/SOAR/eval_dataset/perf_public_set.jsonl"

echo "[prepare_model] Quantizing $MODEL_INPUT -> $MODEL_OUTPUT"

python3 "${SCRIPT_DIR}/preprocess_model_nvfp4_modelopt.py" \
    --input "$MODEL_INPUT" \
    --output "$MODEL_OUTPUT" \
    --config conservative \
    --calib-data "$CALIB_DATA" \
    --num-calib 32

# Ensure hf_quant_config.json has scale_fmt=ue8m0 and correct exclude_modules
python3 - <<'EOF'
import json
path = "/workspace/nvfp4_model/hf_quant_config.json"
_unquant_attn = ["self_attn.qkv_proj", "self_attn.o_proj"]
try:
    with open(path) as f:
        cfg = json.load(f)
    section = cfg.get("quantization", cfg)
    if isinstance(section, dict):
        section["scale_fmt"] = "ue8m0"
        excl = section.get("exclude_modules", [])
        # Remove stale per-layer exact patterns; keep only substring patterns
        excl = [e for e in excl if any(p in e for p in _unquant_attn)]
        for p in _unquant_attn:
            if p not in excl:
                excl.append(p)
        section["exclude_modules"] = excl
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"[prepare_model] patched hf_quant_config.json: scale_fmt=ue8m0, exclude_modules={excl}")
except FileNotFoundError:
    cfg = {"quant_algo": "NVFP4", "scale_fmt": "ue8m0", "exclude_modules": _unquant_attn}
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"[prepare_model] created hf_quant_config.json: {cfg}")
EOF

# Also patch config.json quantization_config if present
python3 - <<'EOF'
import json, os
path = "/workspace/nvfp4_model/config.json"
_unquant_attn = ["self_attn.qkv_proj", "self_attn.o_proj"]
if os.path.exists(path):
    with open(path) as f:
        cfg = json.load(f)
    qc = cfg.get("quantization_config")
    if isinstance(qc, dict):
        qc["scale_fmt"] = "ue8m0"
        excl = qc.get("exclude_modules", [])
        for p in _unquant_attn:
            if p not in excl:
                excl.append(p)
        qc["exclude_modules"] = excl
        with open(path, "w") as f:
            json.dump(cfg, f, indent=2)
        print(f"[prepare_model] patched config.json quantization_config")
EOF

echo "[prepare_model] done: $MODEL_OUTPUT"
