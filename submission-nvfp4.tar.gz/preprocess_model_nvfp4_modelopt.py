"""
NVFP4 model preprocessing using NVIDIA ModelOpt — SOAR 2026.

Uses nvidia-modelopt (already installed on SOAR container) to quantize
MiniCPM-SALA weights to NVFP4 E2M1 format with proper dual-scale mechanism.
ModelOpt produces the exact checkpoint format expected by SGLang's
ModelOptFp4LinearMethod (--quantization modelopt_fp4).

Configs available (choose based on accuracy/speed tradeoff):
  NVFP4_DEFAULT_CFG          — standard NVFP4, all linear layers
  MAMBA_MOE_NVFP4_CONSERVATIVE_CFG — Mamba-aware, conservative (higher accuracy)
  MAMBA_MOE_NVFP4_AGGRESSIVE_CFG  — Mamba-aware, aggressive (higher speed)

Usage:
    python preprocess_model_nvfp4_modelopt.py --input /path/to/model --output /path/to/output
    python preprocess_model_nvfp4_modelopt.py --input /path/to/model --output /path/to/output --config conservative
    python preprocess_model_nvfp4_modelopt.py --input /path/to/model --output /path/to/output --calib-data /path/to/data.jsonl
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


# Verify required deps are available (expected to run under SALA venv which has both)
def _ensure_deps():
    try:
        import flash_attn  # noqa
    except ImportError:
        print("[setup] Installing flash-attn...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "flash-attn", "--no-build-isolation", "-q"],
            check=True,
        )
    try:
        import modelopt  # noqa
        import modelopt.torch.quantization as _mtq  # noqa
        print(f"[setup] modelopt available: {modelopt.__version__}")
    except ImportError:
        print("[setup] Installing nvidia-modelopt...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "nvidia-modelopt", "-q"],
            check=True,
        )


_DEFAULT_CALIB_PROMPTS = [
    "What is the capital of France?",
    "Explain the Pythagorean theorem.",
    "What causes rainbows?",
    "Write a short poem about the ocean.",
    "What is quantum entanglement?",
    "Solve: 2x + 5 = 13. What is x?",
    "What are the main differences between Python and C++?",
    "Describe the process of photosynthesis.",
    "What is the significance of the Turing test?",
    "How does a neural network learn?",
    "What is the speed of light in vacuum?",
    "Explain Newton's second law of motion.",
    "What is the difference between DNA and RNA?",
    "Describe the water cycle.",
    "What is the Higgs boson?",
    "How does a computer CPU work?",
    "What is the theory of relativity?",
    "Explain the concept of entropy in thermodynamics.",
    "What is a black hole?",
    "Describe the structure of an atom.",
    "What is the central limit theorem?",
    "How does HTTPS encryption work?",
    "What is a Fourier transform?",
    "Explain gradient descent in machine learning.",
    "What is the P vs NP problem?",
    "How does the immune system work?",
    "What is CRISPR gene editing?",
    "Explain the concept of a derivative in calculus.",
    "What is the difference between supervised and unsupervised learning?",
    "How does a transformer neural network work?",
    "What is spontaneous symmetry breaking in physics?",
    "Explain the concept of wave-particle duality.",
]

CONFIG_MAP = {
    "default":      "NVFP4_DEFAULT_CFG",
    "conservative": "MAMBA_MOE_NVFP4_CONSERVATIVE_CFG",
    "aggressive":   "MAMBA_MOE_NVFP4_AGGRESSIVE_CFG",
    "mlp-only":     "NVFP4_MLP_ONLY_CFG",
}


def load_calib_prompts(calib_data: str | None, num_calib: int) -> list[str]:
    if calib_data and Path(calib_data).exists():
        prompts = []
        with open(calib_data) as f:
            for line in f:
                if line.strip():
                    item = json.loads(line)
                    q = item.get("question", item.get("text", ""))
                    if q:
                        prompts.append(q)
                    if len(prompts) >= num_calib:
                        break
        print(f"[calib] Loaded {len(prompts)} prompts from {calib_data}")
        return prompts
    else:
        prompts = _DEFAULT_CALIB_PROMPTS[:num_calib]
        print(f"[calib] Using {len(prompts)} built-in prompts")
        return prompts


def main():
    parser = argparse.ArgumentParser(description="MiniCPM-SALA NVFP4 quantization via ModelOpt")
    parser.add_argument("--input",     required=True, help="Original model directory")
    parser.add_argument("--output",    required=True, help="Output directory")
    parser.add_argument("--config",    default="conservative",
                        choices=list(CONFIG_MAP.keys()),
                        help="ModelOpt quantization config (default: conservative)")
    parser.add_argument("--calib-data", default=None,
                        help="JSONL file with calibration prompts (field: 'question')")
    parser.add_argument("--num-calib", type=int, default=32,
                        help="Number of calibration prompts (default: 32)")
    parser.add_argument("--device",    default="cuda")
    args = parser.parse_args()

    src = Path(args.input).resolve()
    dst = Path(args.output).resolve()

    if not src.is_dir():
        raise FileNotFoundError(f"Input model dir not found: {src}")
    dst.mkdir(parents=True, exist_ok=True)

    print(f"[nvfp4-modelopt] input:  {src}")
    print(f"[nvfp4-modelopt] output: {dst}")
    print(f"[nvfp4-modelopt] config: {args.config} ({CONFIG_MAP[args.config]})")

    _ensure_deps()

    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    import modelopt.torch.quantization as mtq
    from modelopt.torch.export import export_hf_checkpoint

    # Load calibration prompts
    prompts = load_calib_prompts(args.calib_data, args.num_calib)

    # Load tokenizer
    print("\n[nvfp4-modelopt] Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(str(src), trust_remote_code=True)

    # Load model in BF16
    print("[nvfp4-modelopt] Loading BF16 model...")
    model = AutoModelForCausalLM.from_pretrained(
        str(src),
        torch_dtype=torch.bfloat16,
        attn_implementation="flash_attention_2",
        trust_remote_code=True,
    ).to(args.device)
    model.eval()
    print(f"[nvfp4-modelopt] Model loaded. Params: {sum(p.numel() for p in model.parameters()) / 1e9:.2f}B")

    # Build calibration dataloader
    def calib_dataloader():
        for prompt in prompts:
            inputs = tokenizer(
                prompt,
                return_tensors="pt",
                truncation=True,
                max_length=512,
            )
            yield {k: v.to(args.device) for k, v in inputs.items()}

    # Get ModelOpt config
    cfg_name = CONFIG_MAP[args.config]
    quant_cfg = getattr(mtq, cfg_name)
    print(f"\n[nvfp4-modelopt] Quantizing with {cfg_name}...")

    # Quantize
    mtq.quantize(model, quant_cfg, forward_loop=calib_dataloader)
    print("[nvfp4-modelopt] Quantization complete.")

    # Export to HF checkpoint format for SGLang --quantization modelopt_fp4.
    # quantize-then-deploy workflow: export produces safetensors with packed FP4 weights.
    dst.mkdir(parents=True, exist_ok=True)
    print(f"[nvfp4-modelopt] Exporting HF checkpoint to {dst}...")
    export_hf_checkpoint(model, export_dir=str(dst))
    print(f"[nvfp4-modelopt] Export complete.")

    print(f"\n[nvfp4-modelopt] Done!")
    print(f"  SGLang: python -m sglang.launch_server --model-path {dst} --quantization modelopt_fp4")


if __name__ == "__main__":
    main()
