#!/usr/bin/env bash

echo "[prepare_env] start $(date '+%F %T')"

uv pip install --no-deps -e ./sglang/python

export SGLANG_SERVER_ARGS="${SGLANG_SERVER_ARGS:-} --mem-fraction-static 0.70 --log-level info"

echo "[prepare_env] done"
